public interface IController {
    void go();
}
