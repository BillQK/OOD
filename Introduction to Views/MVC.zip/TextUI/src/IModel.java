public interface IModel {
  void setString(String i);

  String getString();
}
